


setwd("C://Users//Welcome//Desktop//IT241023245")
getwd()

## Question 01
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE, sep=" ")
fix(Delivery_Times)






## Question 02

## Rename the column name to X
names(Delivery_Times) <- c("X")
attach(Delivery_Times)

histogram <- hist(X, main="Histogram for Delivery Times", breaks=seq(20, 70, length=10), right=TRUE)




## Question 03
## Approximately symmetric and no outliers

## Question 04
freq <- round(histogram$counts)    
breaks <- histogram$breaks  

cumfreq <- cumsum(freq)

plot(breaks[-1], cumfreq, type="o",
     main="Cumulative Frequency Polygon (Ogive)",
     xlab="Delivery Time",
     ylab="Cumulative Frequency")



